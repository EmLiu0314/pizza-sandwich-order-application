﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Our group (ALL OF US) completed our student evaluations!

//AUTHOR:Sara Rasheed, Ryan Lucas, Katelyn Hunt, Emily Liu (Group 2)
//COURSE: ISTM 250.502
//FORM: FRMOrder.cs
//PURPOSE: The purpose of this form is to take orders at Kirby's Deli for pizzas and sandwiches. It takes 
//customer and delivery information (if needed) then adds items to order in a listbox, before placing the order, then 
//removes how much inventory was used for that order.
//INITIALIZE: n/a
//INPUT: The program takes customer information as input, which includes customer name, street address, city, state,
//zip code, phone number, and subdivision. The user also has to use either the carryout or delivery checkbox. The delivery information
//copies all of the customer information but prompts user to input College Station or Bryan as their city. The user also has to choose a 
//type of sandwich or pizza, the type of bread or crust, and the quantity of pizzas or sandwiches that they want to order.
//PROCESS: First, the user will select takeout or delivery, prompting two different user processes. The customer information is inputed,
//and if user has chosen delivery, the default will be their home address. The order section
//as well as crust/ bread options. When the user hits submit the information that has been inputed is validated to ensure that there are no
//errors in. The processing array also keeps track of the inventory item usage for each order being placed.
//OUTPUT: The output on this form is the listbox that populates every item ordered and collects its name, quantity, and subtotal.
//Another output is the subtotal that is calcualted when the clerk chooses an item and enters a quantity. The order total is a 
//running total which includes tax for all items in the list box. When the order is submitted, a message box is outputted, showing the user
//that their order is submitted and what their final total was. Another output is the updated inventory levels that 
//the user can see at any time.
//TERMINATE: n/a
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

namespace CodingProject1
{
    public partial class FRMOrder : Form
    {
        
        public FRMOrder()
        {
            InitializeComponent();        
        }

        //declares needed global variables and sets  them to 0
        decimal decRunningTotal = 0m;
        decimal decSubtotal = 0m;
        decimal decOrderTotal = 0m;



        //array for initial inventory levels
        public decimal[] decInventoryLevels = {200m,
                                        50m,
                                        30m,
                                        25m,
                                        10m,
                                        10m,
                                        20m,
                                        14m,
                                        14m,
                                        10m,
                                        20m,
                                        15m,
                                        12m,
                                        20m,
                                        60m,
                                        25m,
                                        10m,
                                        10m};

        //array for ingredients
        //Columns are: "Ham & Swiss Sandwich", "Turkey & Provolone Sandwich", "BLT Sandwich", 'Med. Cheese Pizza", "Med. Pepperoni Pizza" , "Med. Supreme Pizza"
        decimal[,] decUsage = { {1m, 1m, 1m, 3m, 3m, 3m},                   //0- Flour
                                {0.5m, 0.5m, 0.5m, 2m, 2m, 2m},             //1- Yeast
                                {0.03m, 0.03m, 0.03m, 0.5m, 0.5m, 0.5m},    //2- Sugar
                                {0.05m, 0.05m, 0.05m, 0.1m, 0.1m, 0.1m},    //3- Oil
                                {0.1m, 0m, 0m, 0m, 0m, 0.1m},               //4- Ham
                                {0m, 0.1m, 0m, 0m, 0m, 0.1m },              //5- Turket
                                {0.1m, 0.1m, 0m, 0m, 0m, 0m},               //6- sCheese
                                {0.25m, 0.25m, 0.3m, 0m, 0m, 0m },          //7- Lettuce
                                {0.25m, 0.25m, 0.3m, 0m, 0m, 0.3m },        //8- Tomato
                                {0m, 0m, 0.1m, 0m, 0m, 0.1m },              //9- Bacon
                                {0.02m, 0.02m, 0m, 0m, 0m, 0m},             //10- Pickles
                                {0.02m, 0.02m, 0.02m, 0m, 0m, 0m },         //11- Mayo
                                {0.02m, 0.02m, 0.02m, 0m, 0m, 0m},          //12- Mustard
                                {0m, 0m, 0m, 0m, 0.3m, 0.3m },              //13- Pepprni
                                {0m, 0m, 0m, 1m, 1m, 1m},                   //14- Sauce
                                {0m, 0m, 0m, 0.3m, 0.2m, 0.2m},             //15- gCheese
                                {0.01m, 0.01m, 0.01m, 0.02m, 0.02m, 0.02m}, //16- Salt
                                {0.01m, 0.01m, 0.01m, 0.02m, 0.02m, 0.02m} };//17- Pepper



        //this initializes a new "temporary" array where we will keep a count of all the ingredient usage in each order
        decimal[] decTemporaryArray;
        //this initializes a new "processing" array that stores the ingredient usage for ONE item
        decimal[] decInventoryUsage;

        /// <summary>
        /// when the form loads, this method fills the combobox for items and resets the images, sets default values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMOrder_Load(object sender, EventArgs e)
        {
            //carryout starts as the checkbox already checked, whhich means delivery info groupbox is disabled
            GBXDeliveryInformation.Enabled = false;

            //populate type of sandwhich or pizza in the combo box for sandwich or pizza type
            string[] strTypes = { "Select an item...", "Ham & Swiss Sandwich", "Turkey & Provolone Sandwich", "BLT Sandwich",
                                "Med. Cheese Pizza", "Med. Pepperoni Pizza" , "Med. Supreme Pizza" };

            foreach (string strType in strTypes)
            {
                CBXSandwichPizzaType.Items.Add(strType); //add strTypes array items into the combo box
            }
            CBXSandwichPizzaType.SelectedIndex = 0; //sets the automatic selection of the combo box to "Select an item..."

            //both picture boxes are not visible when the form loads
            PBXSandwich.Visible = false;
            PBXPizza.Visible = false;

            //this loads default info into the customer text boxes when the form loads
            DefaultCustomerInfo();
       
            //this creates a new array with the same length as our original inventory array, but all values are set to 0m
            CreateTemporaryArray();

        }

        /// <summary>
        /// sets automatic values in customer info text boxes
        /// </summary>
        private void DefaultCustomerInfo()
        {
            TXTCustomerName.Text = "John Smith";
            TXTStreetAddress.Text = "123 Main Street";
            TXTCity.Text = "College Station";
            TXTState.Text = "TX";
            TXTZipCode.Text = "77845";
            TXTPhoneNumber.Text = "9799851504";
            TXTSubdivision.Text = "Pebble Creek";
        }

        /// <summary>
        /// This method disables the Delivery groupbox if the carryout checkbox is checked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>     
        private void RDOCarryout_CheckedChanged(object sender, EventArgs e)
        {
            //if the carryout radio button is checked
            if (RDOCarryout.Checked)
            {
                //the user does not have access to the delivery information groupbox
                GBXDeliveryInformation.Enabled = false;
            }
        }

        /// <summary>
        /// this method runs when the delivery radiobutton is checked or unchecked by the clerk
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RDODelivery_CheckedChanged(object sender, EventArgs e)
        {
            try //this net tries to catch all unexpected errors
            {
                if (RDODelivery.Checked) //the entire method runs only if the delivery radiobutton is checked
                {
                    //this validates that the textboxes in the customer information groupbox are filled in, and in the correct formats
                    if (IsValidDataCustomer())
                    {                        

                        GBXDeliveryInformation.Enabled = true; //the groupbox for delivery info becomes enabled

                        //all information from the customer information is transferred to textboxes in the delivery information
                        TXTDeliveryName.Text = TXTCustomerName.Text;
                        TXTDeliveryStreetAddress.Text = TXTStreetAddress.Text;
                        TXTDeliveryInfoCity.Text = TXTCity.Text;
                        TXTDeliveryState.Text = TXTState.Text;
                        TXTDeliveryZipCode.Text = TXTZipCode.Text;
                        TXTDeliveryPhoneNumber.Text = TXTPhoneNumber.Text;
                        TXTDeliverySubdivision.Text = TXTSubdivision.Text;

                        TXTDeliveryStreetAddress.Focus(); //the delivery address textbox is focused

                    }
                    else
                    {
                        RDODelivery.Checked = false; //if the customer information is not all present correctly, the validation sends an error message, and the 
                        //delivery checkbox is set to unchecked
                        RDOCarryout.Checked = true;
                    }
                }

            }
            catch //this catches any unexpected errors in the entry
            {
                MessageBox.Show("Unexpected error. An unexpected error occured. Please try again.", "Error");
            }
        }

        //populate type of bread/crust based on sandwhich or pizza
        /// <summary>
        /// this method populates the crusts and breads based on the type of item selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void CBXSandwichPizzaType_SelectedValueChanged(object sender, EventArgs e)
        {
            //when they select a new item, subtotal resets and quantity resets to avoid false info 
            TXTSubtotal.Clear();
            TXTQuantity.Clear();

            //if they select a sandwich as an item
            if (CBXSandwichPizzaType.SelectedIndex == 1 || CBXSandwichPizzaType.SelectedIndex == 2 || CBXSandwichPizzaType.SelectedIndex == 3)
            {
                                   //Picture box: if combobox chooses sandwhich show sandwhich picture
                PBXSandwich.Visible = true;
                PBXPizza.Visible = false;

                //populate all bread types in CBXBreadCrust 
                string[] strBreads = { "Select a bread...", "White", "Pumpernickel", "Rye", "Sourdough", "Multigrain" };

                CBXCrustOrBreadType.Items.Clear();
                foreach (string strBread in strBreads)
                {
                    CBXCrustOrBreadType.Items.Add(strBread);
                }
                CBXCrustOrBreadType.SelectedIndex = 0;
                //automatically set selected item as "Select a bread..."
               

            }
            //if they want a pizza
            else if (CBXSandwichPizzaType.SelectedIndex == 4 || CBXSandwichPizzaType.SelectedIndex == 5 || CBXSandwichPizzaType.SelectedIndex == 6)
            {
                //Picture box: if combobox chooses pizza show pizza picture
                PBXPizza.Visible = true;
                PBXSandwich.Visible = false;

                //populate the crust types in the combobox
                string[] strCrusts = { "Select a crust...", "Original", "Pan", "Thin", "Wheat" };

                CBXCrustOrBreadType.Items.Clear();
                foreach (string strCrust in strCrusts)
                {
                    CBXCrustOrBreadType.Items.Add(strCrust);
                }
                CBXCrustOrBreadType.SelectedIndex = 0;
                //automatically set selected item as "Select a crust..."
            }


        }

        //if there are no items ordered, the user will be prompted with an errorw 0 in subtotal until eveything is filled out (default value)
        //subtotal calculated when quanitiy put in
        /// <summary>
        /// This method changes the subtotal textbox to the updated subtotal value once the quantity is changed. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTQuantity_TextChanged(object sender, EventArgs e)
        {
            //this checks to make sure the quantity entered is an integer value
            if (Validator.IsInteger(TXTQuantity.Text.Trim(), TXTQuantity.Tag.ToString()))
            {
                //the user cannot submit an order if they somehow have not chosed delivery or carryout
                //decSubtotal = 0m;
                //if they chose a pizza as an item
                if (CBXSandwichPizzaType.SelectedIndex == 4 || CBXSandwichPizzaType.SelectedIndex == 5 || CBXSandwichPizzaType.SelectedIndex == 6)
                {
                    decSubtotal = 9.50m * Convert.ToInt32(TXTQuantity.Text); //take the quantity entered as an integer then multiply it by price
                    TXTSubtotal.Text = decSubtotal.ToString("c"); //display the subtotal in the textbox as currency
                }
                //if they chose a sandwich as an item
                if (CBXSandwichPizzaType.SelectedIndex == 1 || CBXSandwichPizzaType.SelectedIndex == 2 || CBXSandwichPizzaType.SelectedIndex == 3)
                {
                    decSubtotal = 5.00m * Convert.ToInt32(TXTQuantity.Text); //take the quantity entered as an integer then multiply it by price
                    TXTSubtotal.Text = decSubtotal.ToString("c"); //display the subtotal in the textbox as currency
                }
                //if they don't select an item
                if (CBXSandwichPizzaType.SelectedIndex == 0)
                {
                    decSubtotal = 0m; //subtotal displays 0
                    TXTSubtotal.Text = decSubtotal.ToString("c");
                }
            }

        }



        /// <summary>
        /// this method runs the add item button click, it takes the item information and adds it to the listbox, calculates the 
        /// order total, then clears all item information controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNAddItem_Click(object sender, EventArgs e)
        {         
            if (IsValidDataItem()) //this checks if all order item information is present and correctly entered          
            {
                //if item is pizza, price is 9.5
                if (CBXSandwichPizzaType.SelectedIndex == 4 || CBXSandwichPizzaType.SelectedIndex == 5 || CBXSandwichPizzaType.SelectedIndex == 6)
                    LBXOrderedItems.Items.Add(CBXCrustOrBreadType.SelectedItem + " "+ CBXSandwichPizzaType.SelectedItem + ", "  + TXTQuantity.Text + "@$9.50, total: " + decSubtotal.ToString("c"));
                //if item is sandwhich, price is 5
                if(CBXSandwichPizzaType.SelectedIndex == 1 || CBXSandwichPizzaType.SelectedIndex == 2 || CBXSandwichPizzaType.SelectedIndex == 3)
                    LBXOrderedItems.Items.Add(CBXCrustOrBreadType.SelectedItem + " " + CBXSandwichPizzaType.SelectedItem + ", " + TXTQuantity.Text + "@$5, total: " + decSubtotal.ToString("c"));

                //NEW FOR PROJECT 2
                int intQuantity = Convert.ToInt32(TXTQuantity.Text);
                decInventoryUsage = new decimal[decInventoryLevels.Length]; //this inventory usage array starts in the add item button
                //click so it restarts in here

                //this for loop increments through each row (ingredient) on the usage array to find usage for 
                //item ordered then stores that usage times quantity in a new array
                for (int i = 0; i < decUsage.GetLength(0); i++)
                {
                    //when an item is ordered, this finds the amount of each ingredient needed for that item 
                    //then stores it in decIngredientPerItem
                    decimal decIngredientPerItem = decUsage[i, CBXSandwichPizzaType.SelectedIndex-1];
                    //the - 1 is because of the first value being "select an item" in the CBX

                    //this multiplies ingredient needed for the item by the amount ordered
                    //then stores it in the same index value of the "processing" array to keep track of
                    //how much of each ingredient item this item is using
                    decInventoryUsage[i] = (decIngredientPerItem * intQuantity);
                }

                UpdateTemporaryArray(decInventoryUsage); //this sends the usage of each ingredient for the SINGULAR ITEM we added into 
                                                         //an array that is counting how much inventory we are using for the ORDER

                //add subtotal of each section into runningtotal everytime you press add item
                //then take the accumulated running total and multiply by 8.25% to get tax amount
                //
                decRunningTotal += decSubtotal;
                decimal decTax = decRunningTotal * 0.0825m;
                decOrderTotal = decRunningTotal + decTax;
                TXTOrderTotal.Text = decOrderTotal.ToString("c");

                //the comboboxes are changed back to the original selected index
                CBXCrustOrBreadType.SelectedIndex = 0;
                CBXSandwichPizzaType.SelectedIndex = 0;
                //this clears quantity and subtotal
                TXTQuantity.Clear();
                TXTSubtotal.Clear();
                //this makes both picture boxes invisible once item is added
                PBXSandwich.Visible = false;
                PBXPizza.Visible = false;
            }                    
        }

        //submit order clears everything and shows final total in message box
        //dialog box shows order total and confirmation of submission

        /// <summary>
        /// this method makes sure at least one item is added, at least 1 checkbox is checked, and all data is valid, then
        /// submits the order and shows a message box to display that
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNSubmitOrder_Click(object sender, EventArgs e)
        {
            if (LBXOrderedItems.Items.Count == 0) //if the listbox is empty
            {
                MessageBox.Show("Please add at least one item.", "Entry Error");
                TXTQuantity.Clear();

            }
            else
            {
                if (IsValidDataCustomer() && IsValidDataDelivery()) //this validates to make sure customer info is valid and if delivery is selected then delivery
                    //city is college station or bryan and delivery state is tx
                {
                    MessageBox.Show("Your order has been submitted. Your order total was " + decOrderTotal.ToString("c"), "Order Submitted");
                    ClearFields(); //this clears and resets the form for the next customer
                    

                    //when order is submitted, ingredient amount used in the order is subtracted from original inventory levels
                    //for each ingredient
                    for (int i=0; i<decInventoryLevels.Length; i++)
                    {
                        decInventoryLevels[i] -= decTemporaryArray[i];
                    }

                    CreateTemporaryArray(); //this empties any count of usage we were doing since we will be making a new order
                    //it sets the "processing array" of usage back to 0 for each ingredient
                }
            }
            
        }

        /// <summary>
        /// this button runs the clear fields method and resets the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNClearFields_Click(object sender, EventArgs e)
        {
            ClearFields();

            CreateTemporaryArray(); //this empties any count of usage we were doing for an ORDER and resets our temporary processing 
            //array's usage to 0 for each ingredient
        }


        /// <summary>
        /// this method clears all controls on the form / resets them
        /// </summary>
        private void ClearFields()
        {
            RDOCarryout.Checked = true;
            RDODelivery.Checked = false;
            TXTCustomerName.Clear();
            TXTStreetAddress.Clear();
            TXTCity.Clear();
            TXTState.Clear();
            TXTZipCode.Clear();
            TXTPhoneNumber.Clear();
            TXTSubdivision.Clear();
            TXTDeliveryName.Clear();
            TXTDeliveryStreetAddress.Clear();
            TXTDeliveryInfoCity.Clear();
            TXTDeliveryState.Clear();
            TXTDeliveryZipCode.Clear();
            TXTDeliveryPhoneNumber.Clear();
            TXTDeliverySubdivision.Clear();
            LBXOrderedItems.Items.Clear();
            CBXCrustOrBreadType.SelectedIndex = -1; 
            CBXSandwichPizzaType.SelectedIndex = 0;
            TXTQuantity.Clear();
            TXTOrderTotal.Clear();
            decOrderTotal = 0m;
            decSubtotal = 0m;
            decRunningTotal = 0m;
            PBXPizza.Visible = false;
            PBXSandwich.Visible = false;
            DefaultCustomerInfo(); //IS THIS OKAY???
        }

        /// <summary>
        /// this method closes the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// this button lets the user check the inventory levels at any time
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNCheckInventory_Click(object sender, EventArgs e)
        {
            FRMInventory inventoryForm = new FRMInventory(); //this instantiates a copy of the FRM inventory form and creates a template
                                                             //to show it
            inventoryForm.SetInventorylevels(decInventoryLevels); //this calls the SetInventoryLevels method from the inventory form's code
                                                                  //and sends the inventory levels array that is fully updated, into it
            inventoryForm.ShowDialog(); //this then shows the inventory form as a dialog box
        }

 
        /// <summary>
        /// this method updates the inventory usage from each ITEM (decInventoryUsage) and loads it into the temporary array which
        /// stores the inventory usage for the ORDER
        /// </summary>
        /// <param name="decInventoryUsage"></param>
        private void UpdateTemporaryArray(decimal[] decInventoryUsage) //this method should take the usage of EACH item that is added in the "add item" button
            //click then update our temporary array to add that ineventory usage
        {
            for(int i = 0; i < decInventoryLevels.Length; i++)
            {
                decTemporaryArray[i] += decInventoryUsage[i]; //this accumulates the ingredient usage for each ingredient used
                                                              //every time an item is added
            }
        }

        /// <summary>
        /// this method creates the "temporary" array that is set to 0 for all values and tracks the ingredients
        /// used for each ORDER
        /// </summary>
        private void CreateTemporaryArray() //this is gonna create our temporary array and put 0 for every index
            //this method will run each time we submit the order or clear fields
        {
            decTemporaryArray = new decimal[decInventoryLevels.Length]; //the length will be the same as our original inventory levels array

            for (int i = 0; i < decInventoryLevels.Length; i++)
            {
                decTemporaryArray[i] = 0m; //this sets each index value to 0 when this method runs
            }
        }




        #region Validation
        //validation for the customer information
        /// <summary>
        /// this method validates all textboxes in the customer information groupbox
        /// </summary>
        /// <returns></returns>
        private bool IsValidDataCustomer()
        {
            string strErrorMessage = ""; //this may or may not grow larger as we test our inputs.

            //validation for customer name
            strErrorMessage += Validator.IsPresent(TXTCustomerName.Text.Trim(), TXTCustomerName.Tag.ToString());
            strErrorMessage += Validator.IsLetters(TXTCustomerName.Text.Trim(), TXTCustomerName.Tag.ToString());
            //validation for street address
            strErrorMessage += Validator.IsPresent(TXTStreetAddress.Text.Trim(), TXTStreetAddress.Tag.ToString());
            //validation for city
            strErrorMessage += Validator.IsPresent(TXTCity.Text.Trim(), TXTCity.Tag.ToString());
            strErrorMessage += Validator.IsLetters(TXTCity.Text.Trim(), TXTCity.Tag.ToString());
            //validation for state
            strErrorMessage += Validator.IsCorrectNumberOfLetters(TXTState.Text.Trim(), TXTState.Tag.ToString());
            //validation for zip code
            strErrorMessage += Validator.IsCorrectNumberOfZip(TXTZipCode.Text.Trim(), TXTZipCode.Tag.ToString());
            //validation for phone number
            strErrorMessage += Validator.IsCorrectNumberOfPhone(TXTPhoneNumber.Text.Trim(), TXTPhoneNumber.Tag.ToString());
            //validation for subdivision
            strErrorMessage += Validator.IsPresent(TXTSubdivision.Text.Trim(), TXTSubdivision.Tag.ToString());
            strErrorMessage += Validator.IsLetters(TXTSubdivision.Text.Trim(), TXTSubdivision.Tag.ToString());
            

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage, "Customer Information Error");
                return false;               
            }
            else
            {
                return true;
            }
        }
        
        /// <summary>
        /// this method validates for when you click add item, making sure all entries are present and correct
        /// </summary>
        /// <returns></returns>
        private bool IsValidDataItem()
        {

            string strErrorMessage = ""; //this may or may not grow larger as we test our inputs.

            //tests to see if quantity is an integer, and if it is then it checks the number of quantity
            if (Validator.IsInteger(TXTQuantity.Text.Trim(), TXTQuantity.Tag.ToString()))
            {
                strErrorMessage += Validator.IsWithinRange(TXTQuantity.Text.Trim(), TXTQuantity.Tag.ToString(), 1, 100);
                TXTQuantity.Focus();

            }
            else
            {
                strErrorMessage += "Please enter a whole number quantity. \n";
                TXTQuantity.Focus();
            }

            //makes sure there is a value selected for type of crust or bread
            if(CBXCrustOrBreadType.SelectedIndex == 0)

            //makes sure there is a value selected for type of crust or bread
            if(CBXCrustOrBreadType.SelectedIndex == 0)
            {
                strErrorMessage += "Please select a crust or bread type. \n";
                TXTQuantity.Clear();
            }

            //makes sure there is a value selected for type of item
            if(CBXSandwichPizzaType.SelectedIndex == 0)
            {
                strErrorMessage += "Please select an item. \n";
            }
          
            //if there are any errors, a message box will populate
            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage,"Item Entry Error");
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// this method validates the delivery city and state to be bryan tx or college station tx 
        /// </summary>
        /// <returns></returns>
        private bool IsValidDataDelivery()
        {
            string strErrorMessage = "";

            if (RDODelivery.Checked)
            {
                strErrorMessage += Validator.IsCity(TXTDeliveryInfoCity.Text.Trim(), TXTDeliveryInfoCity.Tag.ToString());
                strErrorMessage += Validator.IsState(TXTDeliveryState.Text.Trim(), TXTDeliveryState.Tag.ToString());
            }

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage, "Delivery Location Error");
                return false;
            }
            else
            {
                return true;
            }
        }




        #endregion

        /// <summary>
        /// this method displays the vendor form as a dialog box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNSeeVendors_Click(object sender, EventArgs e)
        {
            FRMVendor vendorForm = new FRMVendor();
            vendorForm.ShowDialog();
        }

        
    }

}


        
     

