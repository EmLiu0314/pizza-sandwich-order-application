using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodingProject1
{
    public static class Validator
    {
        //string method can be used when we do strErrorMessage += IsDigits(parameters)...
        //bool method can be used when we do if(!Validator.IsDigits(parameteres)), then true statement has error message

        //static allows us to use the class without instantiating an object based upon the class

        /// <summary>
        /// this method checks if a value is present in the test value
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsPresent(string strTestValue, string strControlName)
        {
            string strMessage = "";
            if (strTestValue.Trim() == "")
            {
                strMessage += strControlName + " is a required field.\n";
            }
            return strMessage;
        }

        /// <summary>
        /// this method checks to see if the value is an integer
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static bool IsInteger(string strTestValue, string strControlName)
        {
            string strMessage = "";
            if (!Int32.TryParse(strTestValue, out _))
            {
                strMessage += strControlName + " must be a valid integer value.\n";
                return false;
            }
            return true;
        }

        /// <summary>
        /// this method checks to see if the value is within a specified range
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <param name="intMin"></param>
        /// <param name="intMax"></param>
        /// <returns></returns>
        public static string IsWithinRange(string strTestValue, string strControlName, int intMin, decimal intMax)
        {

            int intTestNumber = Convert.ToInt32(strTestValue);
            string strMessage = "";
            if (intTestNumber < intMin || intTestNumber > intMax)
            {
                strMessage += strControlName + " must be between " + intMin + " and " + intMax + ".\n";
            }
            return strMessage;
        }

        //can include punctuation
        /// <summary>
        /// this method checks to see if the value does not include numbers. 
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsLetters (string strTestValue, string strControlName)
        {
            string strErrorMessage = "";

            foreach (char c in strTestValue)
            {
                if (char.IsDigit(c))
                {
                    strErrorMessage = strControlName + " is in the incorrect format. \n";
                }
                else
                {
                    strErrorMessage += "";
                }

            }
            return strErrorMessage;

        }

        public static string IsDigits(string strTestValue, string strControlName)
        {
            string strErrorMessage = "";

            foreach (char c in strTestValue)
            {
                if (char.IsDigit(c))
                {
                    strErrorMessage += "";
                }
                else
                {
                    strErrorMessage = strControlName + " is in the incorrect format. \n";
                }

            }
            return strErrorMessage;

        }

        //CHANGE NUMBER
        //this one is for states --> ex. TX
        /// <summary>
        /// this method checks to make sure that the test value is a certain number of letters
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsCorrectNumberOfLetters(string strTestValue, string strControlName)
        {
            string strErrorMessage = "";

            int i = 0;
            foreach (char c in strTestValue)
            {
                i++;
            }

            if (i != 2)
            {
                strErrorMessage = strControlName + " must be 2 letters. \n";
            }

            return strErrorMessage;
        }

        //string if used normally to validate data
        //CHANGE NUMBER
        //this one is for zipcodes
        /// <summary>
        /// this method checks to see if the zip code is 5 numbers long
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsCorrectNumberOfZip(string strTestValue, string strControlName)
        {
            string strErrorMessage = "";

            int i = 0;
            foreach (char c in strTestValue)
            {
                i++;
            }

            if (i != 5)
            {
                strErrorMessage = strControlName + " must be 5 numbers. \n";
               
            }

            return strErrorMessage;
            //change from "true" to "strErrorMessage" for string
        }



        /// <summary>
        /// checks that there is a valid phone number inputed, must be 10 numbers long
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsCorrectNumberOfPhone(string strTestValue, string strControlName)
        {
            string strErrorMessage = "";

            int i = 0;
            foreach (char c in strTestValue)
            {
                i++;
            }

            if (i != 10)
            {
                strErrorMessage = strControlName + " must be 10 numbers. \n";
                
            }

            return strErrorMessage;
            //change from "true" to "strErrorMessage" for string
        }

        /// <summary>
        /// this method prompts user that the City must be either Bryan OR College Station, if it is not already
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns> <summary>
        /// 
        public static string IsCity(string strTestValue, string strControlName)
        {
            string strMessage = "";
            if (strTestValue.ToLower() != "bryan" && strTestValue.ToLower() != "college station") //if the string is not bryan and if it is not college station 
            {
                strMessage += strControlName + " must be Bryan or College Station.\n";
            }
            return strMessage;
        }

        /// </summary>
        /// prompts user that the state inputed must be Texas, as we only deliver within Texas
        /// 
        /// 
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsState(string strTestValue, string strControlName)
        {
            string strMessage = "";
            if (strTestValue.ToUpper() != "TX") //if the value is not tx
            {
                strMessage += strControlName + " must be TX.\n";
            }
            return strMessage;
        }

        public static string IsDecimal(string strTestValue, string strControlName)
        {
            string strMessage = "";
            if (!decimal.TryParse(strTestValue, out _))
            {
                strMessage += strControlName + " must be a valid decimal value.\n";
            }
            return strMessage;
        }

    }
}
