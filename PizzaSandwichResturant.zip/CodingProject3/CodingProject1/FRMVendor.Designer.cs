﻿namespace CodingProject1
{
    partial class FRMVendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTNNextRecord = new System.Windows.Forms.Button();
            this.BTNPreviousRecord = new System.Windows.Forms.Button();
            this.BTNSaveData = new System.Windows.Forms.Button();
            this.BTNExit = new System.Windows.Forms.Button();
            this.TXTName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TXTStreetAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTCity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TXTState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TXTZipCode = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTPhoneNumber = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TXTYTDSales = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TXTComments = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TXTSalesRepName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.CBXDefaultDiscount = new System.Windows.Forms.ComboBox();
            this.GBXVendorInformation = new System.Windows.Forms.GroupBox();
            this.GBXVendorInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTNNextRecord
            // 
            this.BTNNextRecord.Location = new System.Drawing.Point(456, 415);
            this.BTNNextRecord.Margin = new System.Windows.Forms.Padding(2);
            this.BTNNextRecord.Name = "BTNNextRecord";
            this.BTNNextRecord.Size = new System.Drawing.Size(99, 26);
            this.BTNNextRecord.TabIndex = 2;
            this.BTNNextRecord.Text = "Next Record";
            this.BTNNextRecord.UseVisualStyleBackColor = true;
            this.BTNNextRecord.Click += new System.EventHandler(this.BTNNextRecord_Click);
            // 
            // BTNPreviousRecord
            // 
            this.BTNPreviousRecord.Location = new System.Drawing.Point(572, 415);
            this.BTNPreviousRecord.Margin = new System.Windows.Forms.Padding(2);
            this.BTNPreviousRecord.Name = "BTNPreviousRecord";
            this.BTNPreviousRecord.Size = new System.Drawing.Size(114, 26);
            this.BTNPreviousRecord.TabIndex = 3;
            this.BTNPreviousRecord.Text = "Previous Record";
            this.BTNPreviousRecord.UseVisualStyleBackColor = true;
            this.BTNPreviousRecord.Click += new System.EventHandler(this.BTNPreviousRecord_Click);
            // 
            // BTNSaveData
            // 
            this.BTNSaveData.Location = new System.Drawing.Point(456, 461);
            this.BTNSaveData.Margin = new System.Windows.Forms.Padding(2);
            this.BTNSaveData.Name = "BTNSaveData";
            this.BTNSaveData.Size = new System.Drawing.Size(99, 21);
            this.BTNSaveData.TabIndex = 1;
            this.BTNSaveData.Text = "Save Data";
            this.BTNSaveData.UseVisualStyleBackColor = true;
            this.BTNSaveData.Click += new System.EventHandler(this.BTNSaveData_Click);
            // 
            // BTNExit
            // 
            this.BTNExit.Location = new System.Drawing.Point(572, 461);
            this.BTNExit.Margin = new System.Windows.Forms.Padding(2);
            this.BTNExit.Name = "BTNExit";
            this.BTNExit.Size = new System.Drawing.Size(68, 21);
            this.BTNExit.TabIndex = 4;
            this.BTNExit.Text = "Exit";
            this.BTNExit.UseVisualStyleBackColor = true;
            this.BTNExit.Click += new System.EventHandler(this.BTNExit_Click);
            // 
            // TXTName
            // 
            this.TXTName.Location = new System.Drawing.Point(99, 24);
            this.TXTName.Name = "TXTName";
            this.TXTName.Size = new System.Drawing.Size(100, 20);
            this.TXTName.TabIndex = 0;
            this.TXTName.Tag = "Name";
            this.TXTName.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Street Address:";
            // 
            // TXTStreetAddress
            // 
            this.TXTStreetAddress.Location = new System.Drawing.Point(99, 67);
            this.TXTStreetAddress.Name = "TXTStreetAddress";
            this.TXTStreetAddress.Size = new System.Drawing.Size(100, 20);
            this.TXTStreetAddress.TabIndex = 1;
            this.TXTStreetAddress.Tag = "Street Address";
            this.TXTStreetAddress.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "City:";
            // 
            // TXTCity
            // 
            this.TXTCity.Location = new System.Drawing.Point(99, 124);
            this.TXTCity.Name = "TXTCity";
            this.TXTCity.Size = new System.Drawing.Size(100, 20);
            this.TXTCity.TabIndex = 2;
            this.TXTCity.Tag = "City";
            this.TXTCity.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "State:";
            // 
            // TXTState
            // 
            this.TXTState.Location = new System.Drawing.Point(99, 175);
            this.TXTState.Name = "TXTState";
            this.TXTState.Size = new System.Drawing.Size(100, 20);
            this.TXTState.TabIndex = 3;
            this.TXTState.Tag = "State";
            this.TXTState.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Zip Code:";
            // 
            // TXTZipCode
            // 
            this.TXTZipCode.Location = new System.Drawing.Point(99, 226);
            this.TXTZipCode.Name = "TXTZipCode";
            this.TXTZipCode.Size = new System.Drawing.Size(100, 20);
            this.TXTZipCode.TabIndex = 4;
            this.TXTZipCode.Tag = "Zip Code";
            this.TXTZipCode.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Phone Number:";
            // 
            // TXTPhoneNumber
            // 
            this.TXTPhoneNumber.Location = new System.Drawing.Point(99, 284);
            this.TXTPhoneNumber.Name = "TXTPhoneNumber";
            this.TXTPhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.TXTPhoneNumber.TabIndex = 5;
            this.TXTPhoneNumber.Tag = "Phone Number";
            this.TXTPhoneNumber.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(258, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "YTD Sales:";
            // 
            // TXTYTDSales
            // 
            this.TXTYTDSales.Location = new System.Drawing.Point(384, 14);
            this.TXTYTDSales.Name = "TXTYTDSales";
            this.TXTYTDSales.Size = new System.Drawing.Size(100, 20);
            this.TXTYTDSales.TabIndex = 6;
            this.TXTYTDSales.Tag = "YTD Sales";
            this.TXTYTDSales.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(258, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Comments:";
            // 
            // TXTComments
            // 
            this.TXTComments.Location = new System.Drawing.Point(353, 226);
            this.TXTComments.Name = "TXTComments";
            this.TXTComments.Size = new System.Drawing.Size(211, 20);
            this.TXTComments.TabIndex = 7;
            this.TXTComments.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(258, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Sales Rep Name:";
            // 
            // TXTSalesRepName
            // 
            this.TXTSalesRepName.Location = new System.Drawing.Point(384, 56);
            this.TXTSalesRepName.Name = "TXTSalesRepName";
            this.TXTSalesRepName.Size = new System.Drawing.Size(100, 20);
            this.TXTSalesRepName.TabIndex = 8;
            this.TXTSalesRepName.Tag = "Sales Rep Name";
            this.TXTSalesRepName.TextChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(258, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Default Discount (days):";
            // 
            // CBXDefaultDiscount
            // 
            this.CBXDefaultDiscount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBXDefaultDiscount.FormattingEnabled = true;
            this.CBXDefaultDiscount.Location = new System.Drawing.Point(384, 105);
            this.CBXDefaultDiscount.Name = "CBXDefaultDiscount";
            this.CBXDefaultDiscount.Size = new System.Drawing.Size(121, 21);
            this.CBXDefaultDiscount.TabIndex = 9;
            this.CBXDefaultDiscount.Tag = "Default Discount";
            this.CBXDefaultDiscount.SelectedValueChanged += new System.EventHandler(this.TXTName_TextChanged);
            // 
            // GBXVendorInformation
            // 
            this.GBXVendorInformation.Controls.Add(this.CBXDefaultDiscount);
            this.GBXVendorInformation.Controls.Add(this.label10);
            this.GBXVendorInformation.Controls.Add(this.label9);
            this.GBXVendorInformation.Controls.Add(this.TXTSalesRepName);
            this.GBXVendorInformation.Controls.Add(this.label8);
            this.GBXVendorInformation.Controls.Add(this.TXTComments);
            this.GBXVendorInformation.Controls.Add(this.label7);
            this.GBXVendorInformation.Controls.Add(this.TXTYTDSales);
            this.GBXVendorInformation.Controls.Add(this.label6);
            this.GBXVendorInformation.Controls.Add(this.TXTPhoneNumber);
            this.GBXVendorInformation.Controls.Add(this.label5);
            this.GBXVendorInformation.Controls.Add(this.TXTZipCode);
            this.GBXVendorInformation.Controls.Add(this.label4);
            this.GBXVendorInformation.Controls.Add(this.TXTState);
            this.GBXVendorInformation.Controls.Add(this.label3);
            this.GBXVendorInformation.Controls.Add(this.TXTCity);
            this.GBXVendorInformation.Controls.Add(this.label2);
            this.GBXVendorInformation.Controls.Add(this.TXTStreetAddress);
            this.GBXVendorInformation.Controls.Add(this.label1);
            this.GBXVendorInformation.Controls.Add(this.TXTName);
            this.GBXVendorInformation.Location = new System.Drawing.Point(15, 29);
            this.GBXVendorInformation.Name = "GBXVendorInformation";
            this.GBXVendorInformation.Size = new System.Drawing.Size(650, 348);
            this.GBXVendorInformation.TabIndex = 0;
            this.GBXVendorInformation.TabStop = false;
            this.GBXVendorInformation.Text = "Vendor Information";
            // 
            // FRMVendor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 498);
            this.Controls.Add(this.GBXVendorInformation);
            this.Controls.Add(this.BTNExit);
            this.Controls.Add(this.BTNSaveData);
            this.Controls.Add(this.BTNPreviousRecord);
            this.Controls.Add(this.BTNNextRecord);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FRMVendor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendors";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FRMVendor_FormClosing);
            this.Load += new System.EventHandler(this.FRMVendor_Load);
            this.GBXVendorInformation.ResumeLayout(false);
            this.GBXVendorInformation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTNNextRecord;
        private System.Windows.Forms.Button BTNPreviousRecord;
        private System.Windows.Forms.Button BTNSaveData;
        private System.Windows.Forms.Button BTNExit;
        private System.Windows.Forms.TextBox TXTName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TXTStreetAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTCity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TXTState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TXTZipCode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXTPhoneNumber;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TXTYTDSales;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TXTComments;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TXTSalesRepName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox CBXDefaultDiscount;
        private System.Windows.Forms.GroupBox GBXVendorInformation;
    }
}