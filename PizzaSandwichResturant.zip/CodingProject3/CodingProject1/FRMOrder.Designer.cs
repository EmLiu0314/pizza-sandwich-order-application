﻿namespace CodingProject1
{
    partial class FRMOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMOrder));
            this.LBXOrderedItems = new System.Windows.Forms.ListBox();
            this.CBXSandwichPizzaType = new System.Windows.Forms.ComboBox();
            this.CBXCrustOrBreadType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTQuantity = new System.Windows.Forms.TextBox();
            this.BTNAddItem = new System.Windows.Forms.Button();
            this.BTNSubmitOrder = new System.Windows.Forms.Button();
            this.BTNClearFields = new System.Windows.Forms.Button();
            this.BTNExit = new System.Windows.Forms.Button();
            this.GBXCustomerInformation = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.TXTSubdivision = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TXTPhoneNumber = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TXTZipCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TXTState = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTCity = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TXTStreetAddress = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TXTCustomerName = new System.Windows.Forms.TextBox();
            this.GBXDeliveryInformation = new System.Windows.Forms.GroupBox();
            this.TXTDeliveryInfoCity = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.TXTDeliverySubdivision = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TXTDeliveryPhoneNumber = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.TXTDeliveryZipCode = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.TXTDeliveryState = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.TXTDeliveryStreetAddress = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.TXTDeliveryName = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.TXTOrderTotal = new System.Windows.Forms.TextBox();
            this.TXTSubtotal = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.PBXSandwich = new System.Windows.Forms.PictureBox();
            this.PBXPizza = new System.Windows.Forms.PictureBox();
            this.RDOCarryout = new System.Windows.Forms.RadioButton();
            this.RDODelivery = new System.Windows.Forms.RadioButton();
            this.GBXDeliveryMethod = new System.Windows.Forms.GroupBox();
            this.BTNCheckInventory = new System.Windows.Forms.Button();
            this.BTNSeeVendors = new System.Windows.Forms.Button();
            this.GBXCustomerInformation.SuspendLayout();
            this.GBXDeliveryInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBXSandwich)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBXPizza)).BeginInit();
            this.GBXDeliveryMethod.SuspendLayout();
            this.SuspendLayout();
            // 
            // LBXOrderedItems
            // 
            this.LBXOrderedItems.FormattingEnabled = true;
            this.LBXOrderedItems.Location = new System.Drawing.Point(540, 295);
            this.LBXOrderedItems.Name = "LBXOrderedItems";
            this.LBXOrderedItems.Size = new System.Drawing.Size(474, 251);
            this.LBXOrderedItems.TabIndex = 0;
            this.LBXOrderedItems.TabStop = false;
            // 
            // CBXSandwichPizzaType
            // 
            this.CBXSandwichPizzaType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBXSandwichPizzaType.FormattingEnabled = true;
            this.CBXSandwichPizzaType.Location = new System.Drawing.Point(663, 32);
            this.CBXSandwichPizzaType.Name = "CBXSandwichPizzaType";
            this.CBXSandwichPizzaType.Size = new System.Drawing.Size(206, 21);
            this.CBXSandwichPizzaType.TabIndex = 1;
            this.CBXSandwichPizzaType.Tag = "";
            this.CBXSandwichPizzaType.SelectedValueChanged += new System.EventHandler(this.CBXSandwichPizzaType_SelectedValueChanged);
            // 
            // CBXCrustOrBreadType
            // 
            this.CBXCrustOrBreadType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBXCrustOrBreadType.FormattingEnabled = true;
            this.CBXCrustOrBreadType.Location = new System.Drawing.Point(663, 87);
            this.CBXCrustOrBreadType.Name = "CBXCrustOrBreadType";
            this.CBXCrustOrBreadType.Size = new System.Drawing.Size(121, 21);
            this.CBXCrustOrBreadType.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(596, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Quantity:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(513, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Type of Sandwich / Pizza:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(533, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Type of Bread / Crust:";
            // 
            // TXTQuantity
            // 
            this.TXTQuantity.Location = new System.Drawing.Point(663, 146);
            this.TXTQuantity.Name = "TXTQuantity";
            this.TXTQuantity.Size = new System.Drawing.Size(121, 20);
            this.TXTQuantity.TabIndex = 3;
            this.TXTQuantity.Tag = "Quantity";
            this.TXTQuantity.TextChanged += new System.EventHandler(this.TXTQuantity_TextChanged);
            // 
            // BTNAddItem
            // 
            this.BTNAddItem.Location = new System.Drawing.Point(542, 228);
            this.BTNAddItem.Name = "BTNAddItem";
            this.BTNAddItem.Size = new System.Drawing.Size(75, 23);
            this.BTNAddItem.TabIndex = 4;
            this.BTNAddItem.Text = "Add Item";
            this.BTNAddItem.UseVisualStyleBackColor = true;
            this.BTNAddItem.Click += new System.EventHandler(this.BTNAddItem_Click);
            // 
            // BTNSubmitOrder
            // 
            this.BTNSubmitOrder.Location = new System.Drawing.Point(651, 228);
            this.BTNSubmitOrder.Name = "BTNSubmitOrder";
            this.BTNSubmitOrder.Size = new System.Drawing.Size(96, 23);
            this.BTNSubmitOrder.TabIndex = 5;
            this.BTNSubmitOrder.Text = "Submit Order";
            this.BTNSubmitOrder.UseVisualStyleBackColor = true;
            this.BTNSubmitOrder.Click += new System.EventHandler(this.BTNSubmitOrder_Click);
            // 
            // BTNClearFields
            // 
            this.BTNClearFields.Location = new System.Drawing.Point(842, 228);
            this.BTNClearFields.Name = "BTNClearFields";
            this.BTNClearFields.Size = new System.Drawing.Size(75, 23);
            this.BTNClearFields.TabIndex = 7;
            this.BTNClearFields.TabStop = false;
            this.BTNClearFields.Text = "Clear Fields";
            this.BTNClearFields.UseVisualStyleBackColor = true;
            this.BTNClearFields.Click += new System.EventHandler(this.BTNClearFields_Click);
            // 
            // BTNExit
            // 
            this.BTNExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BTNExit.Location = new System.Drawing.Point(933, 228);
            this.BTNExit.Name = "BTNExit";
            this.BTNExit.Size = new System.Drawing.Size(75, 23);
            this.BTNExit.TabIndex = 7;
            this.BTNExit.Text = "E&xit";
            this.BTNExit.UseVisualStyleBackColor = true;
            this.BTNExit.Click += new System.EventHandler(this.BTNExit_Click);
            // 
            // GBXCustomerInformation
            // 
            this.GBXCustomerInformation.Controls.Add(this.label10);
            this.GBXCustomerInformation.Controls.Add(this.TXTSubdivision);
            this.GBXCustomerInformation.Controls.Add(this.label9);
            this.GBXCustomerInformation.Controls.Add(this.TXTPhoneNumber);
            this.GBXCustomerInformation.Controls.Add(this.label8);
            this.GBXCustomerInformation.Controls.Add(this.TXTZipCode);
            this.GBXCustomerInformation.Controls.Add(this.label7);
            this.GBXCustomerInformation.Controls.Add(this.TXTState);
            this.GBXCustomerInformation.Controls.Add(this.label6);
            this.GBXCustomerInformation.Controls.Add(this.TXTCity);
            this.GBXCustomerInformation.Controls.Add(this.label5);
            this.GBXCustomerInformation.Controls.Add(this.TXTStreetAddress);
            this.GBXCustomerInformation.Controls.Add(this.label4);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerName);
            this.GBXCustomerInformation.Location = new System.Drawing.Point(25, 12);
            this.GBXCustomerInformation.Name = "GBXCustomerInformation";
            this.GBXCustomerInformation.Size = new System.Drawing.Size(474, 239);
            this.GBXCustomerInformation.TabIndex = 11;
            this.GBXCustomerInformation.TabStop = false;
            this.GBXCustomerInformation.Text = "Customer Information";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(237, 157);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Subdivision:";
            // 
            // TXTSubdivision
            // 
            this.TXTSubdivision.Location = new System.Drawing.Point(334, 154);
            this.TXTSubdivision.Name = "TXTSubdivision";
            this.TXTSubdivision.Size = new System.Drawing.Size(100, 20);
            this.TXTSubdivision.TabIndex = 6;
            this.TXTSubdivision.Tag = "Subdivision";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(237, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Phone Number:";
            // 
            // TXTPhoneNumber
            // 
            this.TXTPhoneNumber.Location = new System.Drawing.Point(334, 116);
            this.TXTPhoneNumber.MaxLength = 10;
            this.TXTPhoneNumber.Name = "TXTPhoneNumber";
            this.TXTPhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.TXTPhoneNumber.TabIndex = 5;
            this.TXTPhoneNumber.Tag = "Phone Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 195);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Zip Code:";
            // 
            // TXTZipCode
            // 
            this.TXTZipCode.Location = new System.Drawing.Point(105, 192);
            this.TXTZipCode.MaxLength = 5;
            this.TXTZipCode.Name = "TXTZipCode";
            this.TXTZipCode.Size = new System.Drawing.Size(100, 20);
            this.TXTZipCode.TabIndex = 4;
            this.TXTZipCode.Tag = "Zip Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "State:";
            // 
            // TXTState
            // 
            this.TXTState.Location = new System.Drawing.Point(105, 158);
            this.TXTState.MaxLength = 2;
            this.TXTState.Name = "TXTState";
            this.TXTState.Size = new System.Drawing.Size(100, 20);
            this.TXTState.TabIndex = 3;
            this.TXTState.Tag = "State";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "City:";
            // 
            // TXTCity
            // 
            this.TXTCity.Location = new System.Drawing.Point(105, 116);
            this.TXTCity.Name = "TXTCity";
            this.TXTCity.Size = new System.Drawing.Size(100, 20);
            this.TXTCity.TabIndex = 2;
            this.TXTCity.Tag = "City";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Street Address:";
            // 
            // TXTStreetAddress
            // 
            this.TXTStreetAddress.Location = new System.Drawing.Point(105, 72);
            this.TXTStreetAddress.Name = "TXTStreetAddress";
            this.TXTStreetAddress.Size = new System.Drawing.Size(233, 20);
            this.TXTStreetAddress.TabIndex = 1;
            this.TXTStreetAddress.Tag = "Street Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Customer Name:";
            // 
            // TXTCustomerName
            // 
            this.TXTCustomerName.Location = new System.Drawing.Point(105, 31);
            this.TXTCustomerName.Name = "TXTCustomerName";
            this.TXTCustomerName.Size = new System.Drawing.Size(233, 20);
            this.TXTCustomerName.TabIndex = 0;
            this.TXTCustomerName.Tag = "Customer Name";
            // 
            // GBXDeliveryInformation
            // 
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryInfoCity);
            this.GBXDeliveryInformation.Controls.Add(this.label11);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliverySubdivision);
            this.GBXDeliveryInformation.Controls.Add(this.label12);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryPhoneNumber);
            this.GBXDeliveryInformation.Controls.Add(this.label13);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryZipCode);
            this.GBXDeliveryInformation.Controls.Add(this.label14);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryState);
            this.GBXDeliveryInformation.Controls.Add(this.label15);
            this.GBXDeliveryInformation.Controls.Add(this.label16);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryStreetAddress);
            this.GBXDeliveryInformation.Controls.Add(this.label17);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryName);
            this.GBXDeliveryInformation.Location = new System.Drawing.Point(25, 307);
            this.GBXDeliveryInformation.Name = "GBXDeliveryInformation";
            this.GBXDeliveryInformation.Size = new System.Drawing.Size(474, 239);
            this.GBXDeliveryInformation.TabIndex = 12;
            this.GBXDeliveryInformation.TabStop = false;
            this.GBXDeliveryInformation.Text = "Delivery Information";
            // 
            // TXTDeliveryInfoCity
            // 
            this.TXTDeliveryInfoCity.Location = new System.Drawing.Point(105, 121);
            this.TXTDeliveryInfoCity.Name = "TXTDeliveryInfoCity";
            this.TXTDeliveryInfoCity.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryInfoCity.TabIndex = 28;
            this.TXTDeliveryInfoCity.TabStop = false;
            this.TXTDeliveryInfoCity.Tag = "Delivery City";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(237, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Subdivision:";
            // 
            // TXTDeliverySubdivision
            // 
            this.TXTDeliverySubdivision.Location = new System.Drawing.Point(334, 154);
            this.TXTDeliverySubdivision.Name = "TXTDeliverySubdivision";
            this.TXTDeliverySubdivision.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliverySubdivision.TabIndex = 26;
            this.TXTDeliverySubdivision.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(237, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Phone Number:";
            // 
            // TXTDeliveryPhoneNumber
            // 
            this.TXTDeliveryPhoneNumber.Location = new System.Drawing.Point(334, 116);
            this.TXTDeliveryPhoneNumber.Name = "TXTDeliveryPhoneNumber";
            this.TXTDeliveryPhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryPhoneNumber.TabIndex = 24;
            this.TXTDeliveryPhoneNumber.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "Zip Code:";
            // 
            // TXTDeliveryZipCode
            // 
            this.TXTDeliveryZipCode.Location = new System.Drawing.Point(105, 192);
            this.TXTDeliveryZipCode.Name = "TXTDeliveryZipCode";
            this.TXTDeliveryZipCode.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryZipCode.TabIndex = 22;
            this.TXTDeliveryZipCode.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 161);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "State:";
            // 
            // TXTDeliveryState
            // 
            this.TXTDeliveryState.Location = new System.Drawing.Point(105, 158);
            this.TXTDeliveryState.Name = "TXTDeliveryState";
            this.TXTDeliveryState.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryState.TabIndex = 20;
            this.TXTDeliveryState.TabStop = false;
            this.TXTDeliveryState.Tag = "Delivery State";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 119);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 13);
            this.label15.TabIndex = 19;
            this.label15.Text = "City:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 75);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 17;
            this.label16.Text = "Street Address:";
            // 
            // TXTDeliveryStreetAddress
            // 
            this.TXTDeliveryStreetAddress.Location = new System.Drawing.Point(105, 72);
            this.TXTDeliveryStreetAddress.Name = "TXTDeliveryStreetAddress";
            this.TXTDeliveryStreetAddress.Size = new System.Drawing.Size(233, 20);
            this.TXTDeliveryStreetAddress.TabIndex = 16;
            this.TXTDeliveryStreetAddress.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(85, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "Customer Name:";
            // 
            // TXTDeliveryName
            // 
            this.TXTDeliveryName.Location = new System.Drawing.Point(105, 31);
            this.TXTDeliveryName.Name = "TXTDeliveryName";
            this.TXTDeliveryName.Size = new System.Drawing.Size(233, 20);
            this.TXTDeliveryName.TabIndex = 14;
            this.TXTDeliveryName.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(845, 583);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 13);
            this.label18.TabIndex = 15;
            this.label18.Text = "Order Total:";
            // 
            // TXTOrderTotal
            // 
            this.TXTOrderTotal.Location = new System.Drawing.Point(914, 580);
            this.TXTOrderTotal.Name = "TXTOrderTotal";
            this.TXTOrderTotal.ReadOnly = true;
            this.TXTOrderTotal.Size = new System.Drawing.Size(100, 20);
            this.TXTOrderTotal.TabIndex = 9;
            this.TXTOrderTotal.TabStop = false;
            // 
            // TXTSubtotal
            // 
            this.TXTSubtotal.Location = new System.Drawing.Point(890, 175);
            this.TXTSubtotal.Name = "TXTSubtotal";
            this.TXTSubtotal.ReadOnly = true;
            this.TXTSubtotal.Size = new System.Drawing.Size(118, 20);
            this.TXTSubtotal.TabIndex = 17;
            this.TXTSubtotal.TabStop = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(830, 182);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 13);
            this.label19.TabIndex = 18;
            this.label19.Text = "Subtotal:";
            // 
            // PBXSandwich
            // 
            this.PBXSandwich.Image = ((System.Drawing.Image)(resources.GetObject("PBXSandwich.Image")));
            this.PBXSandwich.InitialImage = null;
            this.PBXSandwich.Location = new System.Drawing.Point(890, 32);
            this.PBXSandwich.Name = "PBXSandwich";
            this.PBXSandwich.Size = new System.Drawing.Size(151, 71);
            this.PBXSandwich.TabIndex = 19;
            this.PBXSandwich.TabStop = false;
            // 
            // PBXPizza
            // 
            this.PBXPizza.Image = ((System.Drawing.Image)(resources.GetObject("PBXPizza.Image")));
            this.PBXPizza.Location = new System.Drawing.Point(890, 12);
            this.PBXPizza.Name = "PBXPizza";
            this.PBXPizza.Size = new System.Drawing.Size(182, 134);
            this.PBXPizza.TabIndex = 20;
            this.PBXPizza.TabStop = false;
            // 
            // RDOCarryout
            // 
            this.RDOCarryout.AutoSize = true;
            this.RDOCarryout.Checked = true;
            this.RDOCarryout.Location = new System.Drawing.Point(26, 20);
            this.RDOCarryout.Name = "RDOCarryout";
            this.RDOCarryout.Size = new System.Drawing.Size(64, 17);
            this.RDOCarryout.TabIndex = 21;
            this.RDOCarryout.TabStop = true;
            this.RDOCarryout.Text = "Carryout";
            this.RDOCarryout.UseVisualStyleBackColor = true;
            this.RDOCarryout.CheckedChanged += new System.EventHandler(this.RDOCarryout_CheckedChanged);
            // 
            // RDODelivery
            // 
            this.RDODelivery.AutoSize = true;
            this.RDODelivery.Location = new System.Drawing.Point(138, 20);
            this.RDODelivery.Name = "RDODelivery";
            this.RDODelivery.Size = new System.Drawing.Size(63, 17);
            this.RDODelivery.TabIndex = 22;
            this.RDODelivery.Text = "Delivery";
            this.RDODelivery.UseVisualStyleBackColor = true;
            this.RDODelivery.CheckedChanged += new System.EventHandler(this.RDODelivery_CheckedChanged);
            // 
            // GBXDeliveryMethod
            // 
            this.GBXDeliveryMethod.Controls.Add(this.RDODelivery);
            this.GBXDeliveryMethod.Controls.Add(this.RDOCarryout);
            this.GBXDeliveryMethod.Location = new System.Drawing.Point(151, 257);
            this.GBXDeliveryMethod.Name = "GBXDeliveryMethod";
            this.GBXDeliveryMethod.Size = new System.Drawing.Size(232, 44);
            this.GBXDeliveryMethod.TabIndex = 0;
            this.GBXDeliveryMethod.TabStop = false;
            this.GBXDeliveryMethod.Text = "Delivery Method";
            // 
            // BTNCheckInventory
            // 
            this.BTNCheckInventory.Location = new System.Drawing.Point(542, 580);
            this.BTNCheckInventory.Name = "BTNCheckInventory";
            this.BTNCheckInventory.Size = new System.Drawing.Size(109, 23);
            this.BTNCheckInventory.TabIndex = 6;
            this.BTNCheckInventory.Text = "Check Inventory";
            this.BTNCheckInventory.UseVisualStyleBackColor = true;
            this.BTNCheckInventory.Click += new System.EventHandler(this.BTNCheckInventory_Click);
            // 
            // BTNSeeVendors
            // 
            this.BTNSeeVendors.Location = new System.Drawing.Point(668, 580);
            this.BTNSeeVendors.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BTNSeeVendors.Name = "BTNSeeVendors";
            this.BTNSeeVendors.Size = new System.Drawing.Size(87, 21);
            this.BTNSeeVendors.TabIndex = 21;
            this.BTNSeeVendors.Text = "See Vendors";
            this.BTNSeeVendors.UseVisualStyleBackColor = true;
            this.BTNSeeVendors.Click += new System.EventHandler(this.BTNSeeVendors_Click);
            // 
            // FRMOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BTNExit;
            this.ClientSize = new System.Drawing.Size(1124, 631);
            this.Controls.Add(this.BTNSeeVendors);
            this.Controls.Add(this.BTNCheckInventory);
            this.Controls.Add(this.GBXDeliveryMethod);
            this.Controls.Add(this.PBXPizza);
            this.Controls.Add(this.PBXSandwich);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.TXTSubtotal);
            this.Controls.Add(this.TXTOrderTotal);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.GBXDeliveryInformation);
            this.Controls.Add(this.GBXCustomerInformation);
            this.Controls.Add(this.BTNExit);
            this.Controls.Add(this.BTNClearFields);
            this.Controls.Add(this.BTNSubmitOrder);
            this.Controls.Add(this.BTNAddItem);
            this.Controls.Add(this.LBXOrderedItems);
            this.Controls.Add(this.TXTQuantity);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CBXCrustOrBreadType);
            this.Controls.Add(this.CBXSandwichPizzaType);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FRMOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Orders";
            this.Load += new System.EventHandler(this.FRMOrder_Load);
            this.GBXCustomerInformation.ResumeLayout(false);
            this.GBXCustomerInformation.PerformLayout();
            this.GBXDeliveryInformation.ResumeLayout(false);
            this.GBXDeliveryInformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBXSandwich)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBXPizza)).EndInit();
            this.GBXDeliveryMethod.ResumeLayout(false);
            this.GBXDeliveryMethod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LBXOrderedItems;
        private System.Windows.Forms.ComboBox CBXSandwichPizzaType;
        private System.Windows.Forms.ComboBox CBXCrustOrBreadType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTQuantity;
        private System.Windows.Forms.Button BTNAddItem;
        private System.Windows.Forms.Button BTNSubmitOrder;
        private System.Windows.Forms.Button BTNClearFields;
        private System.Windows.Forms.Button BTNExit;
        private System.Windows.Forms.GroupBox GBXCustomerInformation;
        private System.Windows.Forms.TextBox TXTCustomerName;
        private System.Windows.Forms.GroupBox GBXDeliveryInformation;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TXTStreetAddress;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TXTSubdivision;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TXTPhoneNumber;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TXTZipCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TXTState;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXTCity;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TXTDeliverySubdivision;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TXTDeliveryPhoneNumber;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TXTDeliveryZipCode;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TXTDeliveryState;
        private System.Windows.Forms.Label label15;
        //private System.Windows.Forms.TextBox TXTDeliveryCity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TXTDeliveryStreetAddress;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox TXTDeliveryName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TXTOrderTotal;
        private System.Windows.Forms.TextBox TXTSubtotal;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox PBXSandwich;
        private System.Windows.Forms.TextBox TXTDeliveryInfoCity;
        private System.Windows.Forms.PictureBox PBXPizza;
        private System.Windows.Forms.RadioButton RDOCarryout;
        private System.Windows.Forms.RadioButton RDODelivery;
        private System.Windows.Forms.GroupBox GBXDeliveryMethod;
        private System.Windows.Forms.Button BTNCheckInventory;
        private System.Windows.Forms.Button BTNSeeVendors;
    }
}

