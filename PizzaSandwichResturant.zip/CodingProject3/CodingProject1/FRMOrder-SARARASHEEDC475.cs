﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//AUTHOR:Sara Rasheed, Ryan Lucas, Katelyn Hunt, Emily Liu (Group 2)
//COURSE: ISTM 250.502
//FORM: FRMOrder.cs
//PURPOSE: 
//INITIALIZE: n/a
//INPUT: 
//PROCESS: 
//OUTPUT:
//TERMINATE: n/a
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”




namespace CodingProject1
{
    public partial class FRMOrder : Form
    {
        decimal decRunningTotal = 0m;
        decimal decSubtotal = 0m;
        decimal decOrderTotal = 0m;


        public FRMOrder()
        {
            InitializeComponent();


            //form load
            //start a list right away??

            GBXDeliveryInformation.Enabled = false;
            CHKCarryout.Checked = true;

            //populate type of sandwhich or pizza
            string[] strTypes = { "Select an item...", "Ham & Swiss Sandwich", "Turkey & Provolone Sandwich", "BLT Sandwich",
                                "Med. Cheese Pizza", "Med. Pepperoni Pizza" , "Med. Supreme Pizza" };

            foreach (string strType in strTypes)
            {
                CBXSandwichPizzaType.Items.Add(strType);
            }
            CBXSandwichPizzaType.SelectedIndex = 0;

            PBXSandwich.Visible = false;
            PBXPizza.Visible = false;

        }


        //if selected carryout, delivery information groupbox disabled      
        private void CHKCarryout_CheckedChanged(object sender, EventArgs e)
        {
            //if the carryout checkbox is checked
            if (CHKCarryout.Checked)
            {
                //the delivery checkbox cannot be checked
                CHKDelivery.Checked = false;
                //the user does not have access to the delivery information groupbox
                GBXDeliveryInformation.Enabled = false;                
            }
        }


        private void CHKDelivery_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if(CHKDelivery.Checked)
                {
                    if (IsValidDataCustomer())
                    {
                        CHKCarryout.Checked = false;

                        GBXDeliveryInformation.Enabled = true;

                        TXTDeliveryName.Text = TXTCustomerName.Text;
                        TXTDeliveryStreetAddress.Text = TXTStreetAddress.Text;
                        TXTDeliveryInfoCity.Text = TXTCity.Text;
                        TXTDeliveryState.Text = TXTState.Text;
                        TXTDeliveryZipCode.Text = TXTZipCode.Text;
                        TXTDeliveryPhoneNumber.Text = TXTPhoneNumber.Text;
                        TXTDeliverySubdivision.Text = TXTSubdivision.Text;

                        //TXTDeliveryStreetAddress.Focus(); //THIS IS HIGHLIGHTING!!

                    }
                    else
                    {
                        CHKDelivery.Checked = false;
                    }
                }
                
            }
            catch //ADD IN OTHER CATCHES???????
            {
                MessageBox.Show("Unexpected error. An unexpected error occured. Please try again.", "Error");
            }
        }


        //populate type of bread/crust based on sandwhich or pizza

        private void CBXSandwichPizzaType_SelectedValueChanged(object sender, EventArgs e)
        {

            //Picture box: if combobox chooses pizza, show pizza picture, if choose sandwhich show sandwhich

            TXTSubtotal.Clear();
            TXTQuantity.Clear();

            //if they select a sandwich
            if (CBXSandwichPizzaType.SelectedIndex == 1 || CBXSandwichPizzaType.SelectedIndex == 2 || CBXSandwichPizzaType.SelectedIndex == 3)
            {

                PBXSandwich.Visible = true;
                PBXPizza.Visible = false;

                //populate all bread types in CBXBreadCrust 
                string[] strBreads = { "Select a bread...", "White", "Pumpernickel", "Rye", "Sourdough", "Multigrain" };

                CBXCrustOrBreadType.Items.Clear();
                foreach (string strBread in strBreads)
                {
                    CBXCrustOrBreadType.Items.Add(strBread);
                }
                CBXCrustOrBreadType.SelectedIndex = 0;

                //PBXSandwichOrPizza.ImageLocation = @"deli.JPG";
               // PBXSandwichOrPizza.Image = deli.JPG
               

            }
            //if they want a pizza
            else if (CBXSandwichPizzaType.SelectedIndex == 4 || CBXSandwichPizzaType.SelectedIndex == 5 || CBXSandwichPizzaType.SelectedIndex == 6)
            {
                PBXPizza.Visible = true;
                PBXSandwich.Visible = false;

                //populate the crust types in the combobox
                string[] strCrusts = { "Select a crust...", "Original", "Pan", "Thin", "Wheat" };

                CBXCrustOrBreadType.Items.Clear();
                foreach (string strCrust in strCrusts)
                {
                    CBXCrustOrBreadType.Items.Add(strCrust);
                }
                CBXCrustOrBreadType.SelectedIndex = 0;
            }

            
        }

        //show 0 in subtotal until eveything is filled out (default value)
        //subtotal calculated when quanitiy put in

        private void TXTQuantity_TextChanged(object sender, EventArgs e)
        {
            if (Validator.IsInteger(TXTQuantity.Text.Trim(), TXTQuantity.Tag.ToString()))
            {
                //decSubtotal = 0m;
                if (CBXSandwichPizzaType.SelectedIndex == 4 || CBXSandwichPizzaType.SelectedIndex == 5 || CBXSandwichPizzaType.SelectedIndex == 6)
                {
                    decSubtotal = 9.50m * Convert.ToInt32(TXTQuantity.Text);
                    TXTSubtotal.Text = decSubtotal.ToString("c");
                }

                if (CBXSandwichPizzaType.SelectedIndex == 1 || CBXSandwichPizzaType.SelectedIndex == 2 || CBXSandwichPizzaType.SelectedIndex == 3)
                {
                    decSubtotal = 5.00m * Convert.ToInt32(TXTQuantity.Text);
                    TXTSubtotal.Text = decSubtotal.ToString("c");
                }

                if (CBXSandwichPizzaType.SelectedIndex == 0 || CBXCrustOrBreadType.SelectedIndex == 0)
                {
                    decSubtotal = 0m;
                    TXTSubtotal.Text = decSubtotal.ToString("c");
                }
            }


        }

        //add item button populates listbox
        //just displaying the infromation in listbox and clears type of sandwhich and such


        //have total with tax show in order total
        //with add item have to update order total

        private void BTNAddItem_Click(object sender, EventArgs e)
        {         
            if (IsValidDataItem())
            {
                //if item is pizza, price is 9.5
                if (CBXSandwichPizzaType.SelectedIndex == 4 || CBXSandwichPizzaType.SelectedIndex == 5 || CBXSandwichPizzaType.SelectedIndex == 6)
                    LBXOrderedItems.Items.Add(CBXCrustOrBreadType.SelectedItem + " "+ CBXSandwichPizzaType.SelectedItem + ", "  + TXTQuantity.Text + "@$9.50, total: " + decSubtotal.ToString("c"));
                //if item is sandwhich, price is 5
                if(CBXSandwichPizzaType.SelectedIndex == 1 || CBXSandwichPizzaType.SelectedIndex == 2 || CBXSandwichPizzaType.SelectedIndex == 3)
                    LBXOrderedItems.Items.Add(CBXCrustOrBreadType.SelectedItem + " " + CBXSandwichPizzaType.SelectedItem + ", " + TXTQuantity.Text + "@$5, total: " + decSubtotal.ToString("c"));

                //add subtotal onto ordertotal everytime you press add item
                //then take the accumulated subtotal and multiply by 8.25%
                decRunningTotal += decSubtotal;
                decimal decTax = decRunningTotal * 0.0825m;
                decOrderTotal = decRunningTotal + decTax;
                TXTOrderTotal.Text = decOrderTotal.ToString("c");

                CBXCrustOrBreadType.SelectedIndex = 0;
                CBXSandwichPizzaType.SelectedIndex = 0;
                TXTQuantity.Clear();
                TXTSubtotal.Clear();
                PBXSandwich.Visible = false;
                PBXPizza.Visible = false;
            }                    
        }

        //submit order clears everything and shows final total in message box
        //dialog box shows order total and confirmation of submission
        private void BTNSubmitOrder_Click(object sender, EventArgs e)
        {
            if(LBXOrderedItems.Items.Count == 0)
            {
                MessageBox.Show("Please add at least one item.","Entry Error");
                TXTQuantity.Clear();
                
            }
            else
            {
                if (IsValidDataCustomer() && IsValidDataDelivery())
                {
                    MessageBox.Show("Your order has been submitted. Your order total was " + decOrderTotal.ToString("c"), "Order Submitted");
                    ClearFields();
                }
            }
            
        }

        /// <summary>
        /// this button runs the clear fields method and resets the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNClearFields_Click(object sender, EventArgs e)
        {

            ClearFields();
        }


        //clear fields clears everything
        //one clear data method
        /// <summary>
        /// this method clears all controls on the form / resets them
        /// </summary>
        private void ClearFields()
        {
            CHKCarryout.Checked = false;
            CHKDelivery.Checked = false;
            TXTCustomerName.Clear();
            TXTStreetAddress.Clear();
            TXTCity.Clear();
            TXTState.Clear();
            TXTZipCode.Clear();
            TXTPhoneNumber.Clear();
            TXTSubdivision.Clear();
            TXTDeliveryName.Clear();
            TXTDeliveryStreetAddress.Clear();
            TXTDeliveryInfoCity.Clear();
            TXTDeliveryState.Clear();
            TXTDeliveryZipCode.Clear();
            TXTDeliveryPhoneNumber.Clear();
            TXTDeliverySubdivision.Clear();
            LBXOrderedItems.Items.Clear();
            CBXCrustOrBreadType.SelectedIndex = -1; 
            CBXSandwichPizzaType.SelectedIndex = 0;
            TXTQuantity.Clear();
            TXTOrderTotal.Clear();
            decOrderTotal = 0m;
            decSubtotal = 0m;
            decRunningTotal = 0m;
            PBXPizza.Visible = false;
            PBXSandwich.Visible = false;
        }

        /// <summary>
        /// this method closes the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNExit_Click(object sender, EventArgs e)
        {
            Close();
        }


        #region Validation
        //validation for the customer information
        private bool IsValidDataCustomer()
        {
            string strErrorMessage = ""; //this may or may not grow larger as we test our inputs.

            //validation for customer name
            strErrorMessage += Validator.IsPresent(TXTCustomerName.Text.Trim(), TXTCustomerName.Tag.ToString());
            strErrorMessage += Validator.IsLetters(TXTCustomerName.Text.Trim(), TXTCustomerName.Tag.ToString());
            //validation for street address
            strErrorMessage += Validator.IsPresent(TXTStreetAddress.Text.Trim(), TXTStreetAddress.Tag.ToString());
            //validation for city
            strErrorMessage += Validator.IsPresent(TXTCity.Text.Trim(), TXTCity.Tag.ToString());
            strErrorMessage += Validator.IsLetters(TXTCity.Text.Trim(), TXTCity.Tag.ToString());
            //validation for state
            strErrorMessage += Validator.IsCorrectNumberOfLetters(TXTState.Text.Trim(), TXTState.Tag.ToString());
            //validation for zip code
            strErrorMessage += Validator.IsCorrectNumberOfZip(TXTZipCode.Text.Trim(), TXTZipCode.Tag.ToString());
            //validation for phone number
            strErrorMessage += Validator.IsCorrectNumberOfPhone(TXTPhoneNumber.Text.Trim(), TXTPhoneNumber.Tag.ToString());
            //validation for subdivision
            strErrorMessage += Validator.IsPresent(TXTSubdivision.Text.Trim(), TXTSubdivision.Tag.ToString());
            strErrorMessage += Validator.IsLetters(TXTSubdivision.Text.Trim(), TXTSubdivision.Tag.ToString());
            

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage);
                return false;               
            }
            else
            {
                return true;
            }
        }

        //validation for when you click add item
        private bool IsValidDataItem()
        {

            string strErrorMessage = ""; //this may or may not grow larger as we test our inputs.

            //tests to see if quantity is an integer, and if it is then it checks the number of quantity
            if (Validator.IsInteger(TXTQuantity.Text.Trim(), TXTQuantity.Tag.ToString()))
            {
                strErrorMessage += Validator.IsWithinRange(TXTQuantity.Text.Trim(), TXTQuantity.Tag.ToString(), 1, 100);
                TXTQuantity.Focus();

            }
            else
            {
                strErrorMessage += "Please enter a whole number quantity. \n";
                TXTQuantity.Focus();
            }

            //makes sure there is a value selected for type of crust or bread
            if(CBXCrustOrBreadType.SelectedIndex == 0)
            {
                strErrorMessage += "Please select a crust or bread type. \n";
            }

            //makes sure there is a value selected for type of item
            if(CBXSandwichPizzaType.SelectedIndex == 0)
            {
                strErrorMessage += "Please select an item. \n";
            }
          

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage);
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// this method validates the delivery city and state to be bryan tx or college station tx 
        /// </summary>
        /// <returns></returns>
        private bool IsValidDataDelivery()
        {
            string strErrorMessage = "";

            if (CHKDelivery.Checked)
            {
                strErrorMessage += Validator.IsCity(TXTDeliveryInfoCity.Text.Trim(), TXTDeliveryInfoCity.Tag.ToString());
                strErrorMessage += Validator.IsState(TXTDeliveryState.Text.Trim(), TXTDeliveryState.Tag.ToString());
            }

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage);
                return false;
            }
            else
            {
                return true;
            }
        }

        #endregion

       
    }

}


        
     

