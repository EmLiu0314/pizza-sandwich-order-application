﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodingProject1
{
    public partial class FRMInventory : Form
    {
        public FRMInventory()
        {
            InitializeComponent();
        }



        /// <summary>
        /// loads in ingredients for inventory levels
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void SetInventorylevels(decimal[] inventoryLevels)
        {
            string[] strIngredients = {"flour",     //0
                                        "yeast",    //1
                                        "sugar",    //2
                                         "oil",     //3
                                         "ham",     //4
                                        "turkey",   //5
                                        "scheese",  //6
                                        "lettuce",  //7
                                        "tomato",   //8
                                        "bacon",    //9
                                        "pickles",  //10
                                        "mayo",     //11
                                        "mustard",  //12
                                        "pepprni",  //13
                                        "sauce",    //14
                                        "gcheese",  //15
                                        "salt",     //16
                                        "pepper"};  //17

            for (int i = 0; i < strIngredients.Length; i++)
            {
                LBXInventoryLevel.Items.Add(strIngredients[i] + " : " + inventoryLevels[i].ToString()); //displays ingredient and level of inventory
            }
        }

        private void BTNClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
