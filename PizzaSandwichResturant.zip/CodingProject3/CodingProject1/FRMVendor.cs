﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Our group (ALL OF US) completed our student evaluations!

namespace CodingProject1
{    
    public partial class FRMVendor : Form
    {
        public FRMVendor()
        {
            InitializeComponent();
        }

        private List<Vendor> lstVendors = null; //starts a list of vendors
        private Vendor newVendor = null; //instantiaates the Vendor class into this form
        int intVendorCountNumber = 0; //begins the vendor count to start iterating through the vendors
        bool blnIsDataSaved = true; //the data saved is set to true before we do anything on the form

        /// <summary>
        /// this method loads the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMVendor_Load(object sender, EventArgs e)
        {
            lstVendors = VendorDB.GetVendors(); //gets vendor info from database and stores it in our list of vendors

            //adds number of days options to discount CBX
            CBXDefaultDiscount.Items.Add(10);
            CBXDefaultDiscount.Items.Add(15);
            CBXDefaultDiscount.Items.Add(20);

            //fill with first vendor information           
            FillVendorInformation(intVendorCountNumber);
        }

        /// <summary>
        /// we will load each vendor's information into the textboxes from the XML file
        /// </summary>
        private void FillVendorInformation(int intVendorCountNumber)
        {
           ClearFields(); //calls on clear fields method to clear all areas of input
           TXTName.Text = lstVendors[intVendorCountNumber].Name; //loads in vendor name (to designated input area)
           TXTStreetAddress.Text = lstVendors[intVendorCountNumber].Address; //loads in vendor address
           TXTCity.Text = lstVendors[intVendorCountNumber].City; //loads in vendor city
           TXTState.Text = lstVendors[intVendorCountNumber].State; //loads in vendor state
           TXTZipCode.Text = lstVendors[intVendorCountNumber].Zip; //loads in vendor zip coode
           TXTPhoneNumber.Text = lstVendors[intVendorCountNumber].Phone; //loads in vendor phone number
           TXTYTDSales.Text = lstVendors[intVendorCountNumber].YTD.ToString(); //loads in vendor YTD
           TXTComments.Text = lstVendors[intVendorCountNumber].Comment; //loads in vendor comment
           TXTSalesRepName.Text = lstVendors[intVendorCountNumber].Contact; //loads in vendor contact
           CBXDefaultDiscount.SelectedItem = lstVendors[intVendorCountNumber].DefaultDiscount; //loads in vendor default discount

        }

        /// <summary>
        /// Clear all the textboxes for a new vendor
        /// </summary>
        private void ClearFields()
        {
            TXTName.Clear();
            TXTStreetAddress.Clear();
            TXTCity.Clear();
            TXTState.Clear();
            TXTZipCode.Clear();
            TXTPhoneNumber.Clear();
            TXTYTDSales.Clear();
            TXTComments.Clear();
            TXTSalesRepName.Clear();
        }      
        
        /// <summary>
        /// Closes the vendor form when the user presses on exit and if all the data is saved
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNExit_Click(object sender, EventArgs e)
        {
            //calls on IsDataSaved before allowing the user to close the form
            if (IsDataSaved(intVendorCountNumber))
            {
                //closes the form
                Close();
            }
        }

        /// <summary>
        /// This method navigates to the next form if the user clicks on the next record button,
        /// and it loops back to the first one once the last vendor is reached
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNNextRecord_Click(object sender, EventArgs e)
        {
            //after validating that changed data is saved, we move our count, and move to the next vendor, then fill the listbox
            if (IsDataSaved(intVendorCountNumber))
            {
                   if (intVendorCountNumber >= ((lstVendors.Count) - 1)) //if we are on the last vendor in our list
                   {
                        intVendorCountNumber = 0; //set vendor count to the first vendor in our list's index
                        FillVendorInformation(intVendorCountNumber); //fill in boxes with first vendor's info
                   }
                   else
                   {
                        intVendorCountNumber += 1; //set count to the next index number
                        FillVendorInformation(intVendorCountNumber); //fill in boxes with next vendor's info
                   }
            }
                                            
        }
        /// <summary>
        /// This method navigates to the previous form if the user clicks on the previous record button,
        /// and it loops back to the last one once the first vendor is reached
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNPreviousRecord_Click(object sender, EventArgs e)
        {
            //after validating that changed data is saved, we move our count, and move to the previous vendor, then fill the listbox
                if (IsDataSaved(intVendorCountNumber)) //once we know the data has been saved
                {
                    if (intVendorCountNumber == 0) //if we are on the first vendor
                    {
                        intVendorCountNumber = lstVendors.Count - 1; //set vendor count to be the last vendor's index in the list
                        FillVendorInformation(intVendorCountNumber); //fill in boxes with the last vendor's info
                    }
                    else //if we are on any other vendor
                    {
                        intVendorCountNumber -= 1; //set count to the previous index number
                        FillVendorInformation(intVendorCountNumber); //fill in boxes with previous vendor's info
                    }
                }           
        }

        /// <summary>
        /// This method checks if all the textboxes are valid, and then saves the data when the user clicks on save data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNSaveData_Click(object sender, EventArgs e)
        {        
            //calls on SaveData method
            SaveData();
        }

        /// <summary>
        /// If the textboxes are valid, The newVendor variable takes whatever
        /// </summary>
        private bool SaveData()
        {
            try
            {
                if (IsValidData()) //checks to see if the data the user entered is valid
                {
                    blnIsDataSaved = true; //changes the bln variable to true

                    //creates a new vendor in the vendor class and enters in the info from the textbox in its correct places
                    newVendor = new Vendor(TXTName.Text.Trim(), TXTStreetAddress.Text.Trim(), TXTCity.Text.Trim(), TXTState.Text.Trim(), TXTZipCode.Text.Trim(),
                        TXTPhoneNumber.Text.Trim(), Convert.ToDecimal(TXTYTDSales.Text.Trim()), TXTComments.Text.Trim(), TXTSalesRepName.Text.Trim(), Convert.ToInt32(CBXDefaultDiscount.SelectedItem));
                    
                    //update our list of vendors with this new vendor's info
                    lstVendors[intVendorCountNumber] = newVendor;

                    //Store vendors into XML for long-term storage
                    VendorDB.SaveVendors(lstVendors);
                    return true;
                    //do everything to save this new data into the XML
                }
                else
                {
                    return false; //data does not save if invalid
                }                
            }
            catch
            {
                MessageBox.Show("An unexpected error occured. Please try again.", "Error");
                return false;
                //if there are any unexpected errors, we send an error message
            }
            

        }

        /// <summary>
        /// this method will keep track of if the user changes information in any of the textboxes. If any info is changed, then our data is set to not saved
        /// </summary>
        /// <param name="intVendorCountNumber"></param>
        /// <returns></returns>
        private bool IsDataSaved (int intVendorCountNumber)
        {
            //checks to see if the text in the textbox is the same as the database, if it's not, then there is unsaved and it will inform the user
            if (TXTName.Text != lstVendors[intVendorCountNumber].Name || TXTStreetAddress.Text != lstVendors[intVendorCountNumber].Address
            || TXTCity.Text != lstVendors[intVendorCountNumber].City
            || TXTState.Text != lstVendors[intVendorCountNumber].State
            || TXTZipCode.Text != lstVendors[intVendorCountNumber].Zip
            || TXTPhoneNumber.Text != lstVendors[intVendorCountNumber].Phone
            || TXTYTDSales.Text != lstVendors[intVendorCountNumber].YTD.ToString()
            || TXTComments.Text != lstVendors[intVendorCountNumber].Comment
            || TXTSalesRepName.Text != lstVendors[intVendorCountNumber].Contact
            || Convert.ToInt32(CBXDefaultDiscount.SelectedItem) != lstVendors[intVendorCountNumber].DefaultDiscount)
            {
                blnIsDataSaved = false; //if the text is not the same, the bln variable is set to false
               
                //present messagebox giving them 3 options to save data, don't save data and throw out, or cancel and take back to form
                DialogResult result = MessageBox.Show("You have unsaved data. Do you want to save?", "Unsaved Data",
                                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                //if they want to save data
                if(result == DialogResult.Yes)
                {
                    //if the user selects Yes then the data is saved
                    if(SaveData())
                    {
                        blnIsDataSaved = true; //if the data was saved successfully
                        return true;
                    }
                    else
                    {
                        return false; //if the data was not saved successfully, the IsDataSaved method returns false
                    }
                }
                else if(result == DialogResult.No) //if the user wants to throw out the data
                {
                    //if the user selects No then the data is not saved
                    blnIsDataSaved = true; //bln variable is true so we can continue our actions
                    return true;
                }
                else if(result == DialogResult.Cancel) //if the user wants to go back on their page
                {
                    //if the user selects Cancel they remain on the landing page that they were attempting to exit
                    return false;                    
                }              
                else return false;
            }
            else
            {
                blnIsDataSaved = true; //this means that all data was the same as the database copy and data is saved
                return true;
            }

        }
        /// <summary>
        /// While form is closing, if data is not saved, the form will ask if they want to save it and if they want to keep the form open then it stays open 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMVendor_FormClosing(object sender, FormClosingEventArgs e)
        { 
                if (blnIsDataSaved == false) //first the form checks if any data has been changed, which means it is not saved
                {
                    if (!IsDataSaved(intVendorCountNumber)) //if there is unsaved data, then it runs the IsDataSaved method to try to save it
                    {
                        e.Cancel = true; //if the data is not saved, the form will stay open
                    }
                }            
        }

        #region Validation
        /// <summary>
        /// this method checks if each textbox is valid
        /// </summary>
        /// <returns></returns>
        private bool IsValidData()
        {
            string strErrormessage = ""; //this may or may not grow larger as we test our inputs

            strErrormessage += Validator.IsPresent(TXTName.Text, TXTName.Tag.ToString()); //makes sure name is present

            strErrormessage += Validator.IsPresent(TXTCity.Text, TXTCity.Tag.ToString()); //makes sure city is present

            strErrormessage += Validator.IsPresent(TXTStreetAddress.Text, TXTStreetAddress.Tag.ToString()); //makes sure street address is present

            strErrormessage += Validator.IsPresent(TXTState.Text, TXTState.Tag.ToString()); //makes sure state is present

            strErrormessage += Validator.IsPresent(TXTZipCode.Text, TXTZipCode.Tag.ToString()); //makes sure zip is present

            strErrormessage += Validator.IsDigits(TXTPhoneNumber.Text, TXTPhoneNumber.Tag.ToString()); //makes sure phone number is present/digits

            strErrormessage += Validator.IsDecimal(TXTYTDSales.Text, TXTYTDSales.Tag.ToString()); //makes sure YTD sales is a decimal

            strErrormessage += Validator.IsPresent(TXTSalesRepName.Text, TXTSalesRepName.Tag.ToString()); //makes sure zip is present

            strErrormessage += Validator.IsLetters(TXTSalesRepName.Text, TXTSalesRepName.Tag.ToString()); //makes sure sales rep name is present/letters

            strErrormessage += Validator.IsPresent(CBXDefaultDiscount.Text, CBXDefaultDiscount.Tag.ToString()); //makes sure a default discount is selected

            //DO NOT NEED TO VALIDATE "COMMENT" BECAUSE IT IS NOT NEEDED INFORMATION

            if (strErrormessage != "") //we accrued one or more errors
            {
                MessageBox.Show(strErrormessage, "Entry Error");
                return false; //we do not have vaid data
            }
            else
            {
                return true; //our data is valid
            }
        }
        #endregion


        /// <summary>
        /// This method checks to see if any of the textbox texts are changed, and if any text changed, blnIsDatasaved is false
        /// and the code knows that the data is not saved
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTName_TextChanged(object sender, EventArgs e)
        {
            //this method will keep track of if the user changes information in any of the textboxes
            //if any info is changed, then our data is set to not saved

            blnIsDataSaved = false;
        }
    }
}
